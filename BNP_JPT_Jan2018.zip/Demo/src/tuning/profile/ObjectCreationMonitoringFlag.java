package tuning.profile;
public class ObjectCreationMonitoringFlag
{
  public static boolean monitoring = false;
}
